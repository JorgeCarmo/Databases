<html>
	<head>
		<meta charset="UTF-8" /> 
	</head>
	<body>
		<h3> Type building information </h3>
		<form action="addBuilding2.php" method="post">
			<p>Morada: <input type="text" name="morada"/></p>
			<p><input type="submit" value="Submit"></p>
		</form>
	</body>
</html>